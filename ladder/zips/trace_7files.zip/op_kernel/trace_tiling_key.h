/*!
 * \file trace_tiling_key.h
 * \brief Tiling 模板参数定义
 */

#ifndef __TRACE_TILING_KEY_H__
#define __TRACE_TILING_KEY_H__

#include "ascendc/host_api/tiling/template_argument.h"

#define TRACE_TPL_SCH_MODE_0 0 // float16
#define TRACE_TPL_SCH_MODE_1 1 // float32

ASCENDC_TPL_ARGS_DECL(
    Trace,
    ASCENDC_TPL_UINT_DECL(schMode, 2, ASCENDC_TPL_UI_LIST, TRACE_TPL_SCH_MODE_0, TRACE_TPL_SCH_MODE_1));

ASCENDC_TPL_SEL(ASCENDC_TPL_ARGS_SEL(
    ASCENDC_TPL_UINT_SEL(schMode, ASCENDC_TPL_UI_LIST, TRACE_TPL_SCH_MODE_0, TRACE_TPL_SCH_MODE_1)));

#endif
