/*!
 * \file conv_transpose2_d.h
 * \brief ConvTranspose2D kernel
 *
 * Semantics (groups = 1):
 *   y[n,co,oh,ow] = sum_{kh,kw,ci} x[n,ci,ih,iw] * w[ci,co,kh,kw] + b[co]
 *   ih = (oh+pad-kh*dil)/stride, iw = (ow+pad-kw*dil)/stride
 *   only integer, in-range (ih,iw) contribute.
 *
 * Path selection by host tiling (field useScalar):
 *  0 = ow-block vectorized path (fast):
 *      For each output row (n,co,oh) the row is processed in 32B-aligned blocks
 *      of WB (=multiple of 64) output elements kept in natural order in UB. For
 *      every (ci,kh,kw) the strided input row (iw = (ow+pad-kw*dil)/stride) is
 *      collected into a contiguous UB vector with Gather using a per-kw
 *      precomputed byte-offset table (invalid positions point at a zero lane).
 *      A vector mac (Axpy) accumulates the block. All vector operands are
 *      32B aligned and all vector op counts are multiples of 64.
 *  1 = scalar GM-direct gather (fallback for extreme shapes / UB overflow).
 *
 * Reduction order (field accMode): the reference implementation accumulates
 *   over the input channels inside one tap first and then over the taps, with
 *   the bias added last.  To stay as close as possible to that rounding:
 *  2 = one accumulator per (kh,kw) tap, channels ascending inside the tap,
 *      taps folded in ascending (kh,kw) order, bias last.  Same association as
 *      the reference and no extra data movement.
 *  1 = one accumulator per (ci,kh) row of kw taps, folded with Kahan
 *      compensation (used when the kh*kw tap accumulators do not fit in UB).
 *  0 = one accumulator per (ci,kh) row of kw taps, plain folding.
 *  3 = single fp32 accumulator written directly (no extra chunk buffer; used
 *      for very long rows so they still run on the vector path).
 *   The bias is added once at the very end in every mode.
 *
 * Work is partitioned by disjoint row / element ranges across AIV cores
 * (no cross-core sync, no atomics -> deterministic output).
 */

#ifndef CONVTRANSPOSE2D_H
#define CONVTRANSPOSE2D_H

#include "kernel_operator.h"
#include "lib/matmul_intf.h"
#include "kernel_tiling/kernel_tiling.h"
#include "conv_transpose2_d_tiling_data.h"
#include "conv_transpose2_d_tiling_key.h"
#include <type_traits>

namespace NsConvTranspose2D {

using namespace AscendC;

__aicore__ inline int64_t Ceil64(int64_t x)
{
    return ((x + 63) / 64) * 64;
}

// vector ops are limited to 255 repeats per call, so long buffers are zeroed in
// slices of 4096 elements (a multiple of the 64 element vector length)
__aicore__ inline void ZeroFill(const LocalTensor<float>& dst, int64_t count)
{
    constexpr int64_t kSlice = 4096;
    for (int64_t o = 0; o < count; o += kSlice) {
        int64_t c = count - o;
        if (c > kSlice) {
            c = kSlice;
        }
        Duplicate(dst[static_cast<int32_t>(o)], 0.0f, static_cast<uint32_t>(c));
    }
}

template <typename T>
class ConvTranspose2D {
public:
    __aicore__ inline ConvTranspose2D() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, const ConvTranspose2DTilingData* tilingData);
    __aicore__ inline void Process();

private:
    // scalar path
    __aicore__ inline float ComputeOne(int64_t idx);
    __aicore__ inline void ScalarProcess();
    __aicore__ inline void FlushChunk(int64_t base, int64_t cnt);
    // vector path
    __aicore__ inline void VectorProcess();
    __aicore__ inline void LoadXRow(int64_t off, int64_t win);
    __aicore__ inline void LoadXSeg(int64_t off, int64_t segLen);
    __aicore__ inline void BuildIdx(int64_t ow0);
    __aicore__ inline void BuildIdxSeg(int64_t ow0, int64_t segStart, int64_t segLen);
    __aicore__ inline void ComputeSeg(int64_t ow0, int64_t blkLen, int64_t& segStart, int64_t& segLen);
    __aicore__ inline void DoRow(int64_t n, int64_t co, int64_t oh, int64_t ow0, int64_t blkLen,
                                 int64_t segStart, int64_t segLen);
    __aicore__ inline void FoldChunk(const LocalTensor<float>& acc, const LocalTensor<float>& tmp);

private:
    TPipe pipe;
    TBuf<QuePosition::VECCALC> fStage;  // scalar staging
    TBuf<QuePosition::VECCALC> fStageH; // scalar fp16 staging
    TBuf<QuePosition::VECCALC> fAcc;    // output row accumulator (accSize)
    TBuf<QuePosition::VECCALC> fTmp;    // per (ci,kh) chunk accumulator (accSize)
    TBuf<QuePosition::VECCALC> fTap;    // per (kh,kw) tap accumulators (kh*kw*accSize)
    TBuf<QuePosition::VECCALC> fComp;   // Kahan compensation (accSize)
    TBuf<QuePosition::VECCALC> fYv;     // Kahan scratch (WB)
    TBuf<QuePosition::VECCALC> fTt;     // Kahan scratch (WB)
    TBuf<QuePosition::VECCALC> fXg;     // gathered x vector (WB)
    TBuf<QuePosition::VECCALC> fX;      // x row (float, p2)
    TBuf<QuePosition::VECCALC> xhBuf;   // x row raw T (fp16)
    TBuf<QuePosition::VECCALC> idxTab;  // gather byte offsets, per kw: [kw*accSize + ow]
    TBuf<QuePosition::VECCALC> accH;    // fp16 output cast

    GlobalTensor<T> xGm;
    GlobalTensor<T> wGm;
    GlobalTensor<float> biasGm;
    GlobalTensor<T> yGm;

    ConvTranspose2DTilingData td_;
    int64_t n_ = 1;
    int64_t chIn_ = 1;
    int64_t chOut_ = 1;
    int64_t hin_ = 1;
    int64_t win_ = 1;
    int64_t hout_ = 1;
    int64_t wout_ = 1;
    int64_t kh_ = 1;
    int64_t kw_ = 1;
    int64_t stride_ = 1;
    int64_t pad_ = 0;
    int64_t outPad_ = 0;
    int64_t dil_ = 1;
    int32_t hasBias_ = 0;
    int64_t chunk_ = 1024;
    int64_t totalOut_ = 0;
    int32_t useScalar_ = 1;
    int32_t accMode_ = 0;

    // vector path derived
    int64_t wb_ = 64;
    int64_t accSize_ = 64;
    int64_t p2_ = 128;
    int64_t zoff_ = 64;
    int32_t winSeg_ = 0;
    int64_t winSegSize_ = 0;
};

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::Init(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y,
                                                const ConvTranspose2DTilingData* tilingData)
{
    td_ = *tilingData;
    n_ = td_.n > 0 ? td_.n : 1;
    chIn_ = td_.chIn > 0 ? td_.chIn : 1;
    chOut_ = td_.chOut > 0 ? td_.chOut : 1;
    hin_ = td_.hin > 0 ? td_.hin : 1;
    win_ = td_.win > 0 ? td_.win : 1;
    hout_ = td_.hout > 0 ? td_.hout : 1;
    wout_ = td_.wout > 0 ? td_.wout : 1;
    kh_ = td_.kh > 0 ? td_.kh : 1;
    kw_ = td_.kw > 0 ? td_.kw : 1;
    stride_ = td_.stride > 0 ? td_.stride : 1;
    pad_ = td_.pad;
    outPad_ = td_.outPad;
    dil_ = td_.dil > 0 ? td_.dil : 1;
    hasBias_ = td_.hasBias;
    totalOut_ = td_.totalNum;
    useScalar_ = td_.useScalar;
    accMode_ = (td_.accMode >= 0 && td_.accMode <= 3) ? td_.accMode : 0;

    chunk_ = td_.ubFactor;
    if (chunk_ < 64) {
        chunk_ = 64;
    }
    chunk_ = (chunk_ / 64) * 64;

    xGm.SetGlobalBuffer((__gm__ T*)x, n_ * chIn_ * hin_ * win_);
    wGm.SetGlobalBuffer((__gm__ T*)w, chIn_ * chOut_ * kh_ * kw_);
    yGm.SetGlobalBuffer((__gm__ T*)y, totalOut_);
    if (hasBias_ != 0) {
        biasGm.SetGlobalBuffer((__gm__ float*)b, chOut_);
    }

    if (useScalar_ != 0) {
        accMode_ = 0;
        pipe.InitBuffer(fStage, static_cast<uint32_t>((chunk_ + 64) * sizeof(float)));
        if constexpr (!std::is_same<T, float>::value) {
            pipe.InitBuffer(fStageH, static_cast<uint32_t>((chunk_ + 64) * sizeof(T)));
        }
        return;
    }

    int64_t woutPad = Ceil64(wout_);
    winSeg_ = td_.winSeg;
    winSegSize_ = td_.winSegSize;
    if (winSeg_ != 0) {
        // only a slice of the x row lives in UB
        p2_ = winSegSize_ + 64;
        zoff_ = winSegSize_;
    } else {
        p2_ = Ceil64(win_ + 64);
        zoff_ = Ceil64(win_);
    }
    if (td_.owBlockSize > 0) {
        accSize_ = td_.owBlockSize;
    } else {
        wb_ = woutPad < 256 ? woutPad : 256;
        if (wb_ < 64) {
            wb_ = 64;
        }
        accSize_ = ((woutPad + wb_ - 1) / wb_) * wb_;
    }
    accSize_ = Ceil64(accSize_);
    if (accSize_ < 64) {
        accSize_ = 64;
    }
    if (td_.wbSize > 0) {
        wb_ = td_.wbSize;
    } else if (accSize_ >= 256 && (accSize_ % 256) == 0) {
        wb_ = 256;
    } else if (accSize_ >= 128 && (accSize_ % 128) == 0) {
        wb_ = 128;
    } else {
        wb_ = 64;
    }
    if (wb_ < 64) {
        wb_ = 64;
    }
    if ((accSize_ % wb_) != 0) {
        accSize_ = ((accSize_ + wb_ - 1) / wb_) * wb_;
    }

    pipe.InitBuffer(fAcc, static_cast<uint32_t>(accSize_ * sizeof(float)));
    pipe.InitBuffer(fXg, static_cast<uint32_t>(wb_ * sizeof(float)));
    pipe.InitBuffer(fX, static_cast<uint32_t>(p2_ * sizeof(float)));
    pipe.InitBuffer(idxTab, static_cast<uint32_t>(kw_ * accSize_ * sizeof(int32_t)));
    if (accMode_ == 2) {
        pipe.InitBuffer(fTap, static_cast<uint32_t>(kh_ * kw_ * accSize_ * sizeof(float)));
    } else if (accMode_ == 1) {
        pipe.InitBuffer(fTmp, static_cast<uint32_t>(accSize_ * sizeof(float)));
        pipe.InitBuffer(fComp, static_cast<uint32_t>(accSize_ * sizeof(float)));
        pipe.InitBuffer(fYv, static_cast<uint32_t>(wb_ * sizeof(float)));
        pipe.InitBuffer(fTt, static_cast<uint32_t>(wb_ * sizeof(float)));
    } else if (accMode_ == 0) {
        pipe.InitBuffer(fTmp, static_cast<uint32_t>(accSize_ * sizeof(float)));
    }
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(xhBuf, static_cast<uint32_t>(p2_ * sizeof(T)));
        pipe.InitBuffer(accH, static_cast<uint32_t>(accSize_ * sizeof(T)));
    }

    // zero the x buffer tail once so padding lanes (and the zoff_ lane) are
    // exactly 0.  Done for both dtypes: the float fX buffer holds the actual
    // gather source, and for fp16 we also clear the raw staging buffer.
    {
        LocalTensor<float> fx = fX.Get<float>();
        Duplicate(fx, 0.0f, static_cast<uint32_t>(p2_));
    }
    if constexpr (!std::is_same<T, float>::value) {
        LocalTensor<T> xh = xhBuf.Get<T>();
        Duplicate(xh, static_cast<T>(0), static_cast<uint32_t>(p2_));
    }

    // precompute per-kw gather byte offsets into fX (float) for the first block
    if (winSeg_ == 0) {
        BuildIdx(0);
    }
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::LoadXRow(int64_t off, int64_t win)
{
    LocalTensor<float> fx = fX.Get<float>();
    PipeBarrier<PIPE_ALL>();  // V(read fX by prev Gather/Axpy) -> MTE2(write fX), WAR
    DataCopyExtParams p;
    p.blockCount = 1;
    p.blockLen = static_cast<uint32_t>(win * sizeof(T));
    p.srcStride = 0;
    p.dstStride = 0;
    p.rsv = 0;
    if constexpr (std::is_same<T, float>::value) {
        DataCopyPad(fx, xGm[off], p, DataCopyPadExtParams<T>{false, 0, 0, 0});
    } else {
        LocalTensor<T> xh = xhBuf.Get<T>();
        DataCopyPad(xh, xGm[off], p, DataCopyPadExtParams<T>{false, 0, 0, 0});
        PipeBarrier<PIPE_ALL>();  // MTE2 -> V
        Cast(fx, xh, RoundMode::CAST_NONE, static_cast<int32_t>(p2_));
    }
    PipeBarrier<PIPE_ALL>();  // MTE2 -> V
}

// Build the per-kw Gather byte-offset table for the output columns
// [ow0, ow0 + accSize_).  Entry (kw, j) points at the float lane of fX that
// holds x[n,ci,ih, iw] for global output column ow = ow0 + j, or at the zero
// lane when that column has no valid input for this tap.
template <typename T>
__aicore__ inline void ConvTranspose2D<T>::BuildIdx(int64_t ow0)
{
    LocalTensor<int32_t> idx = idxTab.Get<int32_t>();
    const int32_t zeroOff = static_cast<int32_t>(zoff_ * 4);
    for (int64_t kw = 0; kw < kw_; ++kw) {
        int64_t baseK = kw * accSize_;
        for (int64_t j = 0; j < accSize_; ++j) {
            int64_t ow = ow0 + j;
            int32_t off = zeroOff;
            if (ow < wout_) {
                int64_t t = ow + pad_ - kw * dil_;
                if (t >= 0 && (t % stride_) == 0) {
                    int64_t iw = t / stride_;
                    if (iw < win_) {
                        off = static_cast<int32_t>(iw * 4);
                    }
                }
            }
            idx.SetValue(static_cast<int32_t>(baseK + j), off);
        }
    }
    PipeBarrier<PIPE_ALL>();
}

// Load only the x slice [segStart, segStart+segLen) of one input row into fX.
template <typename T>
__aicore__ inline void ConvTranspose2D<T>::LoadXSeg(int64_t off, int64_t segLen)
{
    if (segLen <= 0) {
        return;
    }
    LocalTensor<float> fx = fX.Get<float>();
    PipeBarrier<PIPE_ALL>();  // V(read fX) -> MTE2(write fX), WAR
    DataCopyExtParams p;
    p.blockCount = 1;
    p.blockLen = static_cast<uint32_t>(segLen * sizeof(T));
    p.srcStride = 0;
    p.dstStride = 0;
    p.rsv = 0;
    if constexpr (std::is_same<T, float>::value) {
        DataCopyPad(fx, xGm[off], p, DataCopyPadExtParams<T>{false, 0, 0, 0});
    } else {
        LocalTensor<T> xh = xhBuf.Get<T>();
        DataCopyPad(xh, xGm[off], p, DataCopyPadExtParams<T>{false, 0, 0, 0});
        PipeBarrier<PIPE_ALL>();  // MTE2 -> V
        Cast(fx, xh, RoundMode::CAST_NONE, static_cast<int32_t>(Ceil64(segLen)));
    }
    PipeBarrier<PIPE_ALL>();  // MTE2 -> V
}

// Input-column range needed to produce output columns [ow0, ow0+blkLen).
// Covers every tap kw in [0, kw_): iw = (ow + pad - kw*dil) / stride.
template <typename T>
__aicore__ inline void ConvTranspose2D<T>::ComputeSeg(int64_t ow0, int64_t blkLen, int64_t& segStart, int64_t& segLen)
{
    int64_t loT = ow0 + pad_ - (kw_ - 1) * dil_;
    if (loT < 0) {
        loT = 0;
    }
    int64_t hiT = ow0 + blkLen - 1 + pad_;
    int64_t iwLo = loT / stride_;
    int64_t iwHi = hiT / stride_;
    if (iwLo < 0) {
        iwLo = 0;
    }
    if (iwHi > win_ - 1) {
        iwHi = win_ - 1;
    }
    if (iwHi < iwLo || iwLo >= win_) {
        segStart = 0;
        segLen = 0;
        return;
    }
    segStart = iwLo;
    segLen = iwHi - iwLo + 1;
}

// Gather offset table relative to the loaded x slice [segStart, segStart+segLen).
template <typename T>
__aicore__ inline void ConvTranspose2D<T>::BuildIdxSeg(int64_t ow0, int64_t segStart, int64_t segLen)
{
    LocalTensor<int32_t> idx = idxTab.Get<int32_t>();
    const int32_t zeroOff = static_cast<int32_t>(zoff_ * 4);
    const int64_t segEnd = segStart + segLen;
    for (int64_t kw = 0; kw < kw_; ++kw) {
        int64_t baseK = kw * accSize_;
        for (int64_t j = 0; j < accSize_; ++j) {
            int64_t ow = ow0 + j;
            int32_t off = zeroOff;
            if (ow < wout_) {
                int64_t t = ow + pad_ - kw * dil_;
                if (t >= 0 && (t % stride_) == 0) {
                    int64_t iw = t / stride_;
                    if (iw >= segStart && iw < segEnd && iw < win_) {
                        off = static_cast<int32_t>((iw - segStart) * 4);
                    }
                }
            }
            idx.SetValue(static_cast<int32_t>(baseK + j), off);
        }
    }
    PipeBarrier<PIPE_ALL>();
}

// fold the (ci,kh) chunk accumulator into the row accumulator.
// mode 1: Kahan compensated (y = chunk - c; t = acc + y; c = (t - acc) - y; acc = t)
// mode 0: plain add
template <typename T>
__aicore__ inline void ConvTranspose2D<T>::FoldChunk(const LocalTensor<float>& acc,
                                                     const LocalTensor<float>& tmp)
{
    const int64_t nblk = accSize_ / wb_;
    if (accMode_ != 1) {
        for (int64_t b = 0; b < nblk; ++b) {
            const int32_t o = static_cast<int32_t>(b * wb_);
            Add(acc[o], acc[o], tmp[o], static_cast<uint32_t>(wb_));
        }
        return;
    }
    LocalTensor<float> comp = fComp.Get<float>();
    LocalTensor<float> yv = fYv.Get<float>();
    LocalTensor<float> tt = fTt.Get<float>();
    for (int64_t b = 0; b < nblk; ++b) {
        const int32_t o = static_cast<int32_t>(b * wb_);
        Sub(yv, tmp[o], comp[o], static_cast<uint32_t>(wb_));      // yv = chunk - c
        Add(tt, acc[o], yv, static_cast<uint32_t>(wb_));           // tt = acc + yv
        Sub(comp[o], tt, acc[o], static_cast<uint32_t>(wb_));      // comp = tt - acc
        Sub(comp[o], comp[o], yv, static_cast<uint32_t>(wb_));     // comp = (tt - acc) - yv
        Adds(acc[o], tt, 0.0f, static_cast<uint32_t>(wb_));        // acc = tt
    }
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::DoRow(int64_t n, int64_t co, int64_t oh, int64_t ow0, int64_t blkLen,
                                                 int64_t segStart, int64_t segLen)
{
    LocalTensor<float> acc = fAcc.Get<float>();
    LocalTensor<float> xg = fXg.Get<float>();
    LocalTensor<float> fx = fX.Get<float>();
    LocalTensor<uint32_t> idxT = idxTab.Get<int32_t>().template ReinterpretCast<uint32_t>();

    float bias = (hasBias_ != 0) ? biasGm.GetValue(co) : 0.0f;
    Duplicate(acc, 0.0f, static_cast<uint32_t>(accSize_));
    LocalTensor<float> tapBuf;
    if (accMode_ == 2) {
        tapBuf = fTap.Get<float>();
        ZeroFill(tapBuf, kh_ * kw_ * accSize_);
    } else if (accMode_ == 1) {
        Duplicate(fComp.Get<float>(), 0.0f, static_cast<uint32_t>(accSize_));
    }

    const int64_t xStrideC = hin_ * win_;
    const int64_t xStrideN = chIn_ * xStrideC;
    const int64_t wStrideC = chOut_ * kh_ * kw_;
    const int64_t baseXN = n * xStrideN;
    const int64_t nblk = accSize_ / wb_;

    for (int64_t ci = 0; ci < chIn_; ++ci) {
        int64_t xCiN = baseXN + ci * xStrideC;
        for (int64_t kh = 0; kh < kh_; ++kh) {
            int64_t th = oh + pad_ - kh * dil_;
            if (th < 0) {
                break;
            }
            if (th % stride_ != 0) {
                continue;
            }
            int64_t ih = th / stride_;
            if (ih >= hin_) {
                continue;
            }
            if (winSeg_ != 0) {
                LoadXSeg(xCiN + ih * win_ + segStart, segLen);
            } else {
                LoadXRow(xCiN + ih * win_, win_);
            }
            if (accMode_ == 2) {
                // reference order: inside one tap the channels are accumulated
                // in ascending order, so every tap keeps its own accumulator
                for (int64_t kw = 0; kw < kw_; ++kw) {
                    float wv = static_cast<float>(wGm.GetValue(ci * wStrideC + co * kh_ * kw_ + kh * kw_ + kw));
                    int64_t baseK = kw * accSize_;
                    int32_t cbase = static_cast<int32_t>((kh * kw_ + kw) * accSize_);
                    for (int64_t b = 0; b < nblk; ++b) {
                        int64_t ow0 = b * wb_;
                        Gather(xg, fx, idxT[static_cast<int32_t>(baseK + ow0)], 0,
                               static_cast<uint32_t>(wb_));
                        Axpy(tapBuf[cbase + static_cast<int32_t>(ow0)], xg, wv,
                             static_cast<uint32_t>(wb_));
                    }
                }
                continue;
            }
            LocalTensor<float> tmp = (accMode_ == 3) ? acc : fTmp.Get<float>();
            for (int64_t kw = 0; kw < kw_; ++kw) {
                float wv = static_cast<float>(wGm.GetValue(ci * wStrideC + co * kh_ * kw_ + kh * kw_ + kw));
                int64_t baseK = kw * accSize_;
                for (int64_t b = 0; b < nblk; ++b) {
                    int64_t ow0 = b * wb_;
                    Gather(xg, fx, idxT[static_cast<int32_t>(baseK + ow0)], 0,
                           static_cast<uint32_t>(wb_));
                    if (kw == 0 && accMode_ != 3) {
                        Muls(tmp[static_cast<int32_t>(ow0)], xg, wv, static_cast<uint32_t>(wb_));
                    } else {
                        Muls(xg, xg, wv, static_cast<uint32_t>(wb_));
                        Add(tmp[static_cast<int32_t>(ow0)], tmp[static_cast<int32_t>(ow0)], xg,
                            static_cast<uint32_t>(wb_));
                    }
                }
            }
            if (accMode_ != 3) {
                FoldChunk(acc, tmp);
            }
        }
    }

    if (accMode_ == 2) {
        LocalTensor<float> tap = fTap.Get<float>();
        const int64_t nTap = kh_ * kw_;
        // fold the tap accumulators in ascending (kh,kw) order; acc is still 0 so
        // the first add reproduces the reference initialisation exactly
        for (int64_t t = 0; t < nTap; ++t) {
            Add(acc, acc, tap[static_cast<int32_t>(t * accSize_)], static_cast<uint32_t>(accSize_));
        }
    }
    if (hasBias_ != 0) {
        Adds(acc, acc, bias, static_cast<uint32_t>(accSize_));  // bias added last
    }

    int64_t rowBase = ((n * chOut_ + co) * hout_ + oh) * wout_;
    PipeBarrier<PIPE_ALL>();  // V -> MTE3
    if constexpr (std::is_same<T, float>::value) {
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(blkLen * sizeof(float));
        p.srcStride = 0;
        p.dstStride = 0;
        p.rsv = 0;
        DataCopyPad(yGm[rowBase + ow0], acc, p);
    } else {
        LocalTensor<T> ah = accH.Get<T>();
        Cast(ah, acc, RoundMode::CAST_RINT, static_cast<int32_t>(accSize_));
        PipeBarrier<PIPE_ALL>();  // V -> MTE3
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(blkLen * sizeof(T));
        p.srcStride = 0;
        p.dstStride = 0;
        p.rsv = 0;
        DataCopyPad(yGm[rowBase + ow0], ah, p);
    }
    PipeBarrier<PIPE_ALL>();  // MTE3 done before next row reuse
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::VectorProcess()
{
    const int64_t blockNum = static_cast<int64_t>(GetBlockNum());
    const int64_t blockId = static_cast<int64_t>(GetBlockIdx());
    const int64_t rows = n_ * chOut_ * hout_;
    int64_t bn = blockNum < 1 ? 1 : blockNum;
    int64_t per = (rows + bn - 1) / bn;
    if (per < 1) {
        per = 1;
    }
    int64_t s = blockId * per;
    int64_t e = s + per;
    if (e > rows) {
        e = rows;
    }
    if (s >= rows) {
        return;
    }
    const int64_t rowsHW = chOut_ * hout_;
    const int64_t nBlocks = (wout_ + accSize_ - 1) / accSize_;
    for (int64_t b = 0; b < nBlocks; ++b) {
        int64_t ow0 = b * accSize_;
        int64_t blkLen = wout_ - ow0;
        if (blkLen > accSize_) {
            blkLen = accSize_;
        }
        if (blkLen <= 0) {
            break;
        }
        int64_t segStart = 0;
        int64_t segLen = 0;
        if (winSeg_ != 0) {
            ComputeSeg(ow0, blkLen, segStart, segLen);
            BuildIdxSeg(ow0, segStart, segLen);
        } else {
            BuildIdx(ow0);  // offset table is independent of the row
        }
        for (int64_t rid = s; rid < e; ++rid) {
            int64_t n = rid / rowsHW;
            int64_t rr = rid - n * rowsHW;
            int64_t co = rr / hout_;
            int64_t oh = rr - co * hout_;
            DoRow(n, co, oh, ow0, blkLen, segStart, segLen);
        }
    }
}

template <typename T>
__aicore__ inline float ConvTranspose2D<T>::ComputeOne(int64_t idx)
{
    const int64_t hw = hout_ * wout_;
    int64_t tmp = idx;
    int64_t n = tmp / (chOut_ * hw);
    tmp -= n * (chOut_ * hw);
    int64_t co = tmp / hw;
    tmp -= co * hw;
    int64_t oh = tmp / wout_;
    int64_t ow = tmp - oh * wout_;

    // reference order: taps outer, channels ascending, bias last
    float acc = 0.0f;
    const int64_t xStrideC = hin_ * win_;
    const int64_t xStrideN = chIn_ * xStrideC;
    const int64_t wStrideC = chOut_ * kh_ * kw_;
    const int64_t baseX = n * xStrideN;

    for (int64_t kh = 0; kh < kh_; ++kh) {
        int64_t th = oh + pad_ - kh * dil_;
        if (th < 0) {
            break;
        }
        if (th % stride_ != 0) {
            continue;
        }
        int64_t ih = th / stride_;
        if (ih >= hin_) {
            continue;
        }
        for (int64_t kw = 0; kw < kw_; ++kw) {
            int64_t tw = ow + pad_ - kw * dil_;
            if (tw < 0) {
                break;
            }
            if (tw % stride_ != 0) {
                continue;
            }
            int64_t iw = tw / stride_;
            if (iw >= win_) {
                continue;
            }
            int64_t xOff0 = baseX + ih * win_ + iw;
            int64_t wOff0 = co * kh_ * kw_ + kh * kw_ + kw;
            for (int64_t ci = 0; ci < chIn_; ++ci) {
                float xv = static_cast<float>(xGm.GetValue(xOff0 + ci * xStrideC));
                float wv = static_cast<float>(wGm.GetValue(wOff0 + ci * wStrideC));
                acc = xv * wv + acc;
            }
        }
    }
    if (hasBias_ != 0) {
        acc += biasGm.GetValue(co);
    }
    return acc;
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::FlushChunk(int64_t base, int64_t cnt)
{
    LocalTensor<float> f = fStage.Get<float>();
    PipeBarrier<PIPE_ALL>();
    if constexpr (std::is_same<T, float>::value) {
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(cnt * sizeof(float));
        p.srcStride = 0;
        p.dstStride = 0;
        p.rsv = 0;
        DataCopyPad(yGm[base], f, p);
    } else {
        LocalTensor<T> h = fStageH.Get<T>();
        Cast(h, f, RoundMode::CAST_RINT, static_cast<int32_t>(Ceil64(cnt)));
        PipeBarrier<PIPE_ALL>();
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(cnt * sizeof(T));
        p.srcStride = 0;
        p.dstStride = 0;
        p.rsv = 0;
        DataCopyPad(yGm[base], h, p);
    }
    PipeBarrier<PIPE_ALL>();
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::ScalarProcess()
{
    const int64_t blockId = static_cast<int64_t>(GetBlockIdx());
    const int64_t blockNum = static_cast<int64_t>(GetBlockNum());
    int64_t bn = blockNum < 1 ? 1 : blockNum;
    int64_t per = (totalOut_ + bn - 1) / bn;
    if (per < 1) {
        per = 1;
    }
    int64_t s = blockId * per;
    if (s >= totalOut_) {
        return;
    }
    int64_t e = s + per;
    if (e > totalOut_) {
        e = totalOut_;
    }
    LocalTensor<float> f = fStage.Get<float>();
    int64_t base = s;
    while (base < e) {
        int64_t cnt = e - base;
        if (cnt > chunk_) {
            cnt = chunk_;
        }
        for (int64_t j = 0; j < cnt; ++j) {
            f.SetValue(j, ComputeOne(base + j));
        }
        FlushChunk(base, cnt);
        base += cnt;
    }
}

template <typename T>
__aicore__ inline void ConvTranspose2D<T>::Process()
{
    if (useScalar_ != 0) {
        ScalarProcess();
    } else {
        VectorProcess();
    }
}

} // namespace NsConvTranspose2D

/*!
 * \file conv_transpose2_d_cube.h
 * \brief ConvTranspose2D cube (Matmul high level API) path.
 *
 * Work unit = (n, co-block, oh-block):
 *   1. one GEMM per tap: P[t] = W_tap^T (coPer x Cin) @ x[n][:, ihlo*Win : ihhi*Win]
 *   2. vector fold: y[co,oh,ow] = bias + sum_{taps of (oh,ow) phase} P[t][co][pos]
 *   3. near-zero fixup: |y| < fixRatio*rowAbsMax -> reference order recompute
 * Units are independent => no cross-core sync, deterministic output.
 */



namespace NsConvTranspose2D {

using namespace AscendC;
using namespace matmul;

constexpr MatmulConfig CT2D_MM_CFG = GetNormalConfig();
constexpr int64_t CT2D_MAXTAPS = 64;

template <typename T>
class ConvT2DCube {
public:
    using AType = MatmulType<TPosition::GM, CubeFormat::ND, T, true>;
    using BType = MatmulType<TPosition::GM, CubeFormat::ND, T, false>;
    using CType = MatmulType<TPosition::GM, CubeFormat::ND, float>;
    using BiasType = MatmulType<TPosition::GM, CubeFormat::ND, float>;
    Matmul<AType, BType, CType, BiasType, CT2D_MM_CFG> mm;
    TPipe pipe;

    __aicore__ inline ConvT2DCube() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, GM_ADDR userWS,
                                const ConvTranspose2DTilingData* td);
    __aicore__ inline void Process();
    // Tiny 16x16x16 Mmad used by the vector path to make the AIC sub-core take
    // part in the MIX KFC / cross-core handshake (otherwise the AIV-only body
    // leaves AIC waiting and the task stalls until the watchdog fires).
    __aicore__ inline void Handshake(GM_ADDR userWS);

private:
    __aicore__ inline void DoRow(int64_t n, int64_t co, int64_t cLoc, int64_t oh, int64_t ihlo, int64_t nsp,
                                 float bias, int64_t tBase);
    __aicore__ inline void RowExtremes(int64_t cnt, float& mx, float& mn);
    __aicore__ inline void FixupRow(int64_t n, int64_t co, int64_t oh, float bias, float cut);

    GlobalTensor<T> xGm;
    GlobalTensor<T> wGm;
    GlobalTensor<T> yGm;
    GlobalTensor<float> bGm;
    GlobalTensor<float> pGm;
    GlobalTensor<T> wcGm;

    TBuf<TPosition::VECCALC> fAccAll;
    TBuf<TPosition::VECCALC> fIdxY;
    TBuf<TPosition::VECCALC> fIdxT;
    TBuf<TPosition::VECCALC> fP;
    TBuf<TPosition::VECCALC> fG;
    TBuf<TPosition::VECCALC> fY;
    TBuf<TPosition::VECCALC> fYh;
    TBuf<TPosition::VECCALC> fYabs;
    TBuf<TPosition::VECCALC> fRed;
    TBuf<TPosition::VECCALC> fRmn;
    TBuf<TPosition::VECCALC> fXL;
    TBuf<TPosition::VECCALC> fXLH;
    TBuf<TPosition::VECCALC> fTapDot;
    TBuf<TPosition::VECCALC> fFixOw;
    TBuf<TPosition::VECCALC> fWH;
    TBuf<TPosition::VECCALC> fWgAll;
    TBuf<TPosition::VECCALC> fWidx;

    ConvTranspose2DTilingData td_;
    int64_t n_ = 1, chIn_ = 1, chOut_ = 1, hin_ = 1, win_ = 1, hout_ = 1, wout_ = 1;
    int64_t kh_ = 1, kw_ = 1, s_ = 1, pad_ = 0, dil_ = 1;
    int64_t hinWin_ = 1, ntaps_ = 1, lenSec_ = 64, coPer_ = 1, ohPer_ = 1, coBlocks_ = 1, ohBlocks_ = 1;
    int64_t units_ = 1, perCoreElems_ = 1, nspanMax_ = 1, nfix_ = 8, coreNum_ = 1, coPad_ = 16;
    int64_t wout64_ = 64, winPad_ = 128, zlane_ = 0, win64_ = 64;
    int64_t coutPad_ = 0, wcElems_ = 0, wcMax_ = 0, coutPad64_ = 64;
    float fixRatio_ = 5e-4f;
    int32_t tapPh_[CT2D_MAXTAPS], tapPw_[CT2D_MAXTAPS], tapCh_[CT2D_MAXTAPS], tapCw_[CT2D_MAXTAPS];
    int32_t tapJ0_[CT2D_MAXTAPS], tapJ1_[CT2D_MAXTAPS];
    int32_t jwlo_[8], lenPw_[8];
    bool hasBias_ = true;
};

template <typename T>
__aicore__ inline void ConvT2DCube<T>::Init(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, GM_ADDR userWS,
                                            const ConvTranspose2DTilingData* td)
{
    td_ = *td;
    n_ = td_.n; chIn_ = td_.chIn; chOut_ = td_.chOut; hin_ = td_.hin; win_ = td_.win;
    hout_ = td_.hout; wout_ = td_.wout; kh_ = td_.kh; kw_ = td_.kw;
    s_ = td_.stride; pad_ = td_.pad; dil_ = td_.dil;
    hinWin_ = td_.hinWin; ntaps_ = td_.ntaps; lenSec_ = td_.lenSec;
    coPer_ = td_.coPer; ohPer_ = td_.ohPer; coBlocks_ = td_.coBlocks; ohBlocks_ = td_.ohBlocks;
    units_ = td_.units; perCoreElems_ = td_.perCoreElems; nspanMax_ = td_.nspanMax;
    nfix_ = td_.nfix; coreNum_ = td_.coreNum; coPad_ = td_.coPerPad;
    coutPad_ = td_.coutPad; wcElems_ = td_.wcElems;
    fixRatio_ = td_.fixRatio;
    hasBias_ = (td_.hasBias != 0);
    wout64_ = ((wout_ + 63) / 64) * 64;
    if (wout64_ < 64) { wout64_ = 64; }
    win64_ = ((win_ + 63) / 64) * 64;
    if (win64_ < 64) { win64_ = 64; }
    winPad_ = ((win_ + 16 + 63) / 64) * 64;
    zlane_ = winPad_;  // zero lane lives just past every loaded window
    for (int32_t i = 0; i < 8; ++i) { jwlo_[i] = td_.jwlo[i]; lenPw_[i] = td_.lenPw[i]; }
    for (int32_t i = 0; i < CT2D_MAXTAPS; ++i) {
        tapPh_[i] = -1; tapPw_[i] = 0; tapCh_[i] = 0; tapCw_[i] = 0; tapJ0_[i] = 0; tapJ1_[i] = 0;
    }

    xGm.SetGlobalBuffer((__gm__ T*)x, n_ * chIn_ * hinWin_);
    wGm.SetGlobalBuffer((__gm__ T*)w, chIn_ * chOut_ * ntaps_);
    yGm.SetGlobalBuffer((__gm__ T*)y, n_ * chOut_ * hout_ * wout_);
    if (hasBias_) { bGm.SetGlobalBuffer((__gm__ float*)b, chOut_); }
    pGm.SetGlobalBuffer((__gm__ float*)userWS, coreNum_ * perCoreElems_);
    wcGm.SetGlobalBuffer((__gm__ T*)(userWS + static_cast<uint64_t>(coreNum_ * perCoreElems_) * sizeof(float)),
                         static_cast<uint64_t>(coreNum_) * static_cast<uint64_t>(wcElems_));

    pipe.InitBuffer(fAccAll, static_cast<uint32_t>(s_ * lenSec_ * sizeof(float) + 256));
    pipe.InitBuffer(fIdxY, static_cast<uint32_t>(wout64_ * sizeof(int32_t) + 256));
    pipe.InitBuffer(fIdxT, static_cast<uint32_t>(ntaps_ * lenSec_ * sizeof(int32_t) + 256));
    pipe.InitBuffer(fP, static_cast<uint32_t>((winPad_ + 64) * sizeof(float)));
    pipe.InitBuffer(fG, static_cast<uint32_t>(lenSec_ * sizeof(float) + 256));
    pipe.InitBuffer(fY, static_cast<uint32_t>(wout64_ * sizeof(float) + 256));
    pipe.InitBuffer(fYabs, static_cast<uint32_t>(wout64_ * sizeof(float) + 256));
    pipe.InitBuffer(fRed, static_cast<uint32_t>(wout64_ * sizeof(float) + 256));
    pipe.InitBuffer(fRmn, static_cast<uint32_t>(wout64_ * sizeof(float) + 256));
    pipe.InitBuffer(fYh, static_cast<uint32_t>(wout64_ * sizeof(T) + 256));
    pipe.InitBuffer(fXLH, static_cast<uint32_t>(win64_ * sizeof(T) + 256));
    pipe.InitBuffer(fXL, static_cast<uint32_t>(win64_ * sizeof(float) + 256));
    pipe.InitBuffer(fTapDot, static_cast<uint32_t>(nfix_ * ntaps_ * sizeof(float) + 256));
    pipe.InitBuffer(fFixOw, static_cast<uint32_t>(nfix_ * sizeof(int32_t) + 256));
    coutPad64_ = ((coutPad_ + 63) / 64) * 64;
    wcMax_ = ((chOut_ * ntaps_ + 63) / 64) * 64 + 64;
    if (coutPad_ > 0) {
        pipe.InitBuffer(fWH, static_cast<uint32_t>(wcMax_ * sizeof(T)));
        pipe.InitBuffer(fWgAll, static_cast<uint32_t>(ntaps_ * coutPad64_ * sizeof(T) + 256));
        pipe.InitBuffer(fWidx, static_cast<uint32_t>(ntaps_ * coutPad64_ * sizeof(int32_t) + 256));
    }

    LocalTensor<float> fp = fP.Get<float>();
    Duplicate(fp, 0.0f, static_cast<uint32_t>(winPad_ + 64));

    LocalTensor<uint32_t> idxT = fIdxT.Get<int32_t>().template ReinterpretCast<uint32_t>();
    for (int64_t t = 0; t < ntaps_; ++t) {
        int64_t kh = t / kw_;
        int64_t kwv = t - kh * kw_;
        int64_t ph = (kh * dil_) % s_;
        int64_t pw = (kwv * dil_) % s_;
        int64_t ch = (ph - kh * dil_) / s_;
        int64_t cw = (pw - kwv * dil_) / s_;
        int64_t jwlo = jwlo_[pw];
        int64_t len = lenPw_[pw];
        int64_t j0 = -cw - jwlo;
        if (j0 < 0) { j0 = 0; }
        int64_t j1 = win_ - cw - jwlo;
        if (j1 > len) { j1 = len; }
        if (j1 < j0) { j1 = j0; }
        tapPh_[t] = static_cast<int32_t>(ph);
        tapPw_[t] = static_cast<int32_t>(pw);
        tapCh_[t] = static_cast<int32_t>(ch);
        tapCw_[t] = static_cast<int32_t>(cw);
        tapJ0_[t] = static_cast<int32_t>(j0);
        tapJ1_[t] = static_cast<int32_t>(j1);
        int64_t sOff = jwlo + j0 + cw;
        int64_t aStart = (sOff / 8) * 8;
        int64_t extra = sOff - aStart;
        for (int64_t j = 0; j < lenSec_; ++j) {
            int32_t byteOff = static_cast<int32_t>(zlane_ * 4);
            if (j >= j0 && j < j1) {
                byteOff = static_cast<int32_t>((extra + (j - j0)) * 4);
            }
            idxT.SetValue(static_cast<int32_t>(t * lenSec_ + j), static_cast<uint32_t>(byteOff));
        }
    }
    // ---- materialise per-tap contiguous weights wC[t][ci][co] = w[ci][co][kh,kw] ----
    if (coutPad_ > 0 && wcElems_ > 0) {
        LocalTensor<T> fwh = fWH.Get<T>();
        LocalTensor<T> fwall = fWgAll.Get<T>();
        LocalTensor<uint32_t> widx = fWidx.Get<int32_t>().template ReinterpretCast<uint32_t>();
        const int64_t blk = static_cast<int64_t>(GetBlockIdx());
        const int64_t wcBase = blk * wcElems_;
        const int32_t zl = static_cast<int32_t>(((chOut_ * ntaps_ + 63) / 64) * 64 * sizeof(T));
        for (int64_t t = 0; t < ntaps_; ++t) {
            for (int64_t co = 0; co < coutPad64_; ++co) {
                int32_t off = zl;
                if (co < chOut_) { off = static_cast<int32_t>((co * ntaps_ + t) * sizeof(T)); }
                widx.SetValue(static_cast<int32_t>(t * coutPad64_ + co), static_cast<uint32_t>(off));
            }
        }
        Duplicate(fwh, static_cast<T>(0), static_cast<uint32_t>(wcMax_));
        PipeBarrier<PIPE_ALL>();
        for (int64_t ci = 0; ci < chIn_; ++ci) {
            DataCopyExtParams lp;
            lp.blockCount = 1;
            lp.blockLen = static_cast<uint32_t>(chOut_ * ntaps_ * sizeof(T));
            lp.srcStride = 0; lp.dstStride = 0; lp.rsv = 0;
            DataCopyPad(fwh, wGm[ci * chOut_ * ntaps_], lp, DataCopyPadExtParams<T>{false, 0, 0, 0});
            PipeBarrier<PIPE_ALL>();
            for (int64_t t = 0; t < ntaps_; ++t) {
                Gather(fwall[t * static_cast<int32_t>(coutPad64_)], fwh, widx[t * coutPad64_], 0,
                       static_cast<uint32_t>(coutPad64_));
            }
            PipeBarrier<PIPE_ALL>();
            for (int64_t t = 0; t < ntaps_; ++t) {
                DataCopyExtParams sp;
                sp.blockCount = 1;
                sp.blockLen = static_cast<uint32_t>(coutPad_ * sizeof(T));
                sp.srcStride = 0; sp.dstStride = 0; sp.rsv = 0;
                DataCopyPad(wcGm[wcBase + t * chIn_ * coutPad_ + ci * coutPad_],
                            fwall[t * static_cast<int32_t>(coutPad64_)], sp);
            }
            PipeBarrier<PIPE_ALL>();
        }
    }

    LocalTensor<uint32_t> idxY = fIdxY.Get<int32_t>().template ReinterpretCast<uint32_t>();
    for (int64_t ow = 0; ow < wout64_; ++ow) {
        int32_t byteOff = 0;
        if (ow < wout_) {
            int64_t pw = (ow + pad_) % s_;
            int64_t jw = (ow + pad_ - pw) / s_;
            byteOff = static_cast<int32_t>((pw * lenSec_ + (jw - jwlo_[pw])) * 4);
        }
        idxY.SetValue(static_cast<int32_t>(ow), static_cast<uint32_t>(byteOff));
    }
    PipeBarrier<PIPE_ALL>();
}

template <typename T>
__aicore__ inline void ConvT2DCube<T>::RowExtremes(int64_t cnt, float& mx, float& mn)
{
    LocalTensor<float> a = fRed.Get<float>();
    LocalTensor<float> bmin = fRmn.Get<float>();
    LocalTensor<float> src = fYabs.Get<float>();
    int64_t n64 = ((cnt + 63) / 64) * 64;
    Adds(a, src, 0.0f, static_cast<uint32_t>(n64));
    Adds(bmin, src, 0.0f, static_cast<uint32_t>(n64));
    int64_t len = n64;
    while (len > 64) {
        int64_t half = len / 2;
        Max(a, a, a[static_cast<int32_t>(half)], static_cast<uint32_t>(half));
        Min(bmin, bmin, bmin[static_cast<int32_t>(half)], static_cast<uint32_t>(half));
        len = half;
    }
    mx = a.GetValue(0);
    mn = bmin.GetValue(0);
    for (int64_t j = 1; j < len; ++j) {
        float v = a.GetValue(static_cast<int32_t>(j));
        if (v > mx) { mx = v; }
        float w = bmin.GetValue(static_cast<int32_t>(j));
        if (w < mn) { mn = w; }
    }
}

template <typename T>
__aicore__ inline void ConvT2DCube<T>::DoRow(int64_t n, int64_t co, int64_t cLoc, int64_t oh, int64_t ihlo,
                                             int64_t nsp, float bias, int64_t tBase)
{
    LocalTensor<float> accAll = fAccAll.Get<float>();
    LocalTensor<float> fg = fG.Get<float>();
    LocalTensor<float> fp = fP.Get<float>();
    LocalTensor<uint32_t> idxT = fIdxT.Get<int32_t>().template ReinterpretCast<uint32_t>();
    LocalTensor<uint32_t> idxY = fIdxY.Get<int32_t>().template ReinterpretCast<uint32_t>();
    LocalTensor<float> yrow = fY.Get<float>();
    LocalTensor<T> yh = fYh.Get<T>();

    for (int64_t pw = 0; pw < s_; ++pw) {
        Duplicate(accAll[static_cast<int32_t>(pw * lenSec_)], 0.0f, static_cast<uint32_t>(lenSec_));
    }
    PipeBarrier<PIPE_ALL>();

    const int64_t nRows = nsp / win_;
    int64_t ph = (oh + pad_) % s_;
    int64_t jh = (oh + pad_ - ph) / s_;

    for (int64_t t = 0; t < ntaps_; ++t) {
        if (tapPh_[t] != ph) { continue; }
        int64_t ih = jh + tapCh_[t];
        if (ih < ihlo || ih >= ihlo + nRows) { continue; }
        if (ih < 0 || ih >= hin_) { continue; }
        int64_t j0 = tapJ0_[t], j1 = tapJ1_[t];
        if (j1 <= j0) { continue; }
        int64_t sOff = (ih - ihlo) * win_ + tapJ0_[t] + tapCw_[t] + jwlo_[tapPw_[t]];
        int64_t aStart = (sOff / 8) * 8;
        int64_t extra = sOff - aStart;
        int64_t loadLen = extra + (j1 - j0);
        loadLen = ((loadLen + 7) / 8) * 8;
        if (loadLen > win_ + 16) { loadLen = win_ + 16; }
        DataCopyExtParams cp;
        cp.blockCount = 1;
        cp.blockLen = static_cast<uint32_t>(loadLen * sizeof(float));
        cp.srcStride = 0;
        cp.dstStride = 0;
        cp.rsv = 0;
        DataCopyPad(fp, pGm[tBase + t * coPad_ * nsp + cLoc * nsp + aStart], cp,
                    DataCopyPadExtParams<float>{false, 0, 0, 0});
        SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
        WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
        Gather(fg, fp, idxT[static_cast<int32_t>(t * lenSec_)], 0, static_cast<uint32_t>(lenSec_));
        int32_t sec = static_cast<int32_t>(tapPw_[t] * lenSec_);
        Add(accAll[sec], accAll[sec], fg, static_cast<uint32_t>(lenSec_));
        SetFlag<HardEvent::V_MTE2>(EVENT_ID0);
        WaitFlag<HardEvent::V_MTE2>(EVENT_ID0);
    }

    Gather(yrow, accAll, idxY, 0, static_cast<uint32_t>(wout64_));
    if (hasBias_) {
        Adds(yrow, yrow, bias, static_cast<uint32_t>(wout64_));
    }
    LocalTensor<float> yabs = fYabs.Get<float>();
    Abs(yabs, yrow, static_cast<uint32_t>(wout64_));
    for (int64_t j = wout_; j < wout64_; ++j) {
        yabs.SetValue(static_cast<int32_t>(j), 0.0f);  /* pad=0: must not raise max */
    }
    float mx = 0.0f, mn = 0.0f;
    RowExtremes(wout_, mx, mn);
    if (mn < fixRatio_ * mx) {
        FixupRow(n, co, oh, bias, fixRatio_ * mx);
    }

    int64_t rowBase = ((n * chOut_ + co) * hout_ + oh) * wout_;
    SetFlag<HardEvent::V_MTE3>(EVENT_ID0);
    WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);
    if constexpr (std::is_same<T, float>::value) {
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(wout_ * sizeof(float));
        p.srcStride = 0; p.dstStride = 0; p.rsv = 0;
        DataCopyPad(yGm[rowBase], yrow, p);
    } else {
        Cast(yh, yrow, RoundMode::CAST_RINT, static_cast<int32_t>(wout64_));
        SetFlag<HardEvent::V_MTE3>(EVENT_ID0);
        WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);
        DataCopyExtParams p;
        p.blockCount = 1;
        p.blockLen = static_cast<uint32_t>(wout_ * sizeof(T));
        p.srcStride = 0; p.dstStride = 0; p.rsv = 0;
        DataCopyPad(yGm[rowBase], yh, p);
    }
    SetFlag<HardEvent::MTE3_V>(EVENT_ID0);
    WaitFlag<HardEvent::MTE3_V>(EVENT_ID0);
}

template <typename T>
__aicore__ inline void ConvT2DCube<T>::FixupRow(int64_t n, int64_t co, int64_t oh, float bias, float cut)
{
    LocalTensor<float> yrow = fY.Get<float>();
    LocalTensor<float> yabs = fYabs.Get<float>();
    LocalTensor<int32_t> fow = fFixOw.Get<int32_t>();
    LocalTensor<float> tapDot = fTapDot.Get<float>();
    LocalTensor<float> fxl = fXL.Get<float>();
    LocalTensor<T> fxlh = fXLH.Get<T>();

    int64_t cnt = 0;
    for (int64_t ow = 0; ow < wout_ && cnt < nfix_; ++ow) {
        if (yabs.GetValue(static_cast<int32_t>(ow)) < cut) {
            fow.SetValue(static_cast<int32_t>(cnt), static_cast<int32_t>(ow));
            cnt++;
        }
    }
    if (cnt <= 0) { return; }
    for (int64_t e = 0; e < cnt; ++e) {
        for (int64_t t = 0; t < ntaps_; ++t) {
            tapDot.SetValue(static_cast<int32_t>(e * ntaps_ + t), 0.0f);
        }
    }
    const int64_t xStrideC = hinWin_;
    const int64_t wStrideC = chOut_ * ntaps_;
    const int64_t baseX = n * chIn_ * xStrideC;
    for (int64_t ci = 0; ci < chIn_; ++ci) {
        for (int64_t kh = 0; kh < kh_; ++kh) {
            int64_t th = oh + pad_ - kh * dil_;
            if (th < 0) { break; }
            if (th % s_ != 0) { continue; }
            int64_t ih = th / s_;
            if (ih >= hin_) { continue; }
            DataCopyExtParams xp;
            xp.blockCount = 1;
            xp.blockLen = static_cast<uint32_t>(win_ * sizeof(T));
            xp.srcStride = 0; xp.dstStride = 0; xp.rsv = 0;
            if constexpr (std::is_same<T, float>::value) {
                DataCopyPad(fxl, xGm[baseX + ci * xStrideC + ih * win_], xp,
                            DataCopyPadExtParams<T>{false, 0, 0, 0});
            } else {
                DataCopyPad(fxlh, xGm[baseX + ci * xStrideC + ih * win_], xp,
                            DataCopyPadExtParams<T>{false, 0, 0, 0});
                SetFlag<HardEvent::MTE2_V>(EVENT_ID1);
                WaitFlag<HardEvent::MTE2_V>(EVENT_ID1);
                Cast(fxl, fxlh, RoundMode::CAST_NONE, static_cast<int32_t>(win64_));
            }
            SetFlag<HardEvent::MTE2_V>(EVENT_ID1);
            WaitFlag<HardEvent::MTE2_V>(EVENT_ID1);
            for (int64_t kw = 0; kw < kw_; ++kw) {
                float wv = static_cast<float>(wGm.GetValue(ci * wStrideC + co * ntaps_ + kh * kw_ + kw));
                int64_t t = kh * kw_ + kw;
                for (int64_t e = 0; e < cnt; ++e) {
                    int64_t ow = static_cast<int64_t>(fow.GetValue(static_cast<int32_t>(e)));
                    int64_t tw = ow + pad_ - kw * dil_;
                    if (tw < 0) { break; }
                    if (tw % s_ != 0) { continue; }
                    int64_t iw = tw / s_;
                    if (iw >= win_) { continue; }
                    float xv = fxl.GetValue(static_cast<int32_t>(iw));
                    float cur = tapDot.GetValue(static_cast<int32_t>(e * ntaps_ + t));
                    tapDot.SetValue(static_cast<int32_t>(e * ntaps_ + t), xv * wv + cur);
                }
            }
        }
    }
    for (int64_t e = 0; e < cnt; ++e) {
        float acc = 0.0f;
        for (int64_t t = 0; t < ntaps_; ++t) {
            acc += tapDot.GetValue(static_cast<int32_t>(e * ntaps_ + t));
        }
        acc += bias;
        int64_t ow = static_cast<int64_t>(fow.GetValue(static_cast<int32_t>(e)));
        yrow.SetValue(static_cast<int32_t>(ow), acc);
    }
    PipeBarrier<PIPE_ALL>();
}

template <typename T>
__aicore__ inline void ConvT2DCube<T>::Handshake(GM_ADDR userWS)
{
    // Scratch lives in user workspace: A (256 T), B (256 T), C (256 float).
    GlobalTensor<T> aG;
    GlobalTensor<T> bG;
    GlobalTensor<float> cG;
    aG.SetGlobalBuffer((__gm__ T*)(userWS), 256);
    bG.SetGlobalBuffer((__gm__ T*)(userWS + 1024), 256);
    cG.SetGlobalBuffer((__gm__ float*)(userWS + 2048), 256);
    mm.SetOrgShape(16, 16, 16, 16, 16);
    mm.SetSingleShape(16, 16, 16);
    mm.SetTensorA(aG, false);
    mm.SetTensorB(bG, false);
    mm.IterateAll(cG, 0);
    mm.End();
}

template <typename T>
__aicore__ inline void ConvT2DCube<T>::Process()
{
    if (units_ <= 0) { mm.End(); return; }
    const int64_t blockId = static_cast<int64_t>(GetBlockIdx());
    if (blockId >= coreNum_) { mm.End(); return; }
    const int64_t uPer = ((units_ + coreNum_ - 1) / coreNum_);
    const int64_t u0 = blockId * uPer;
    int64_t u1 = u0 + uPer;
    if (u1 > units_) { u1 = units_; }

    for (int64_t u = u0; u < u1; ++u) {
        int64_t n = u / (coBlocks_ * ohBlocks_);
        int64_t rem = u - n * coBlocks_ * ohBlocks_;
        int64_t cb = rem / ohBlocks_;
        int64_t ob = rem - cb * ohBlocks_;
        int64_t co0 = cb * coPer_;
        int64_t co1 = co0 + coPer_;
        if (co1 > chOut_) { co1 = chOut_; }
        int64_t coCur = co1 - co0;
        int64_t oh0 = ob * ohPer_;
        int64_t oh1 = oh0 + ohPer_;
        if (oh1 > hout_) { oh1 = hout_; }
        if (coCur <= 0 || oh1 <= oh0) { continue; }
        int64_t tLo = oh0 + pad_ - (kh_ - 1) * dil_;
        int64_t ihlo = (tLo >= 0) ? (tLo / s_) : -(((-tLo) + s_ - 1) / s_);
        if (ihlo < 0) { ihlo = 0; }
        const int64_t nRows = nspanMax_ / win_;
        if (ihlo + nRows > hin_) { ihlo = hin_ - nRows; }
        if (ihlo < 0) { ihlo = 0; }
        const int64_t nsp = nspanMax_;
        int64_t tBase = blockId * perCoreElems_;

        for (int64_t t = 0; t < ntaps_; ++t) {
            // qmsq recipe: (orgM, orgN=B's N axis, orgKa=A row stride, orgKb=B row
            // stride, orgKc=C's N axis). orgN is hinWin (full x row) while C's N is nsp.
            mm.SetOrgShape(static_cast<int>(coutPad_), static_cast<int>(nsp),
                           static_cast<int>(coutPad_), static_cast<int>(hinWin_),
                           static_cast<int>(nsp));
            /* pad the GEMM M tile up to coPerPad (>= baseM): an M below baseM corrupts
             * the C column write-back (only the first few ow columns were right). Rows
             * past coCur read zero-padded A columns and are discarded by the fold. */
            mm.SetSingleShape(static_cast<int>(coPad_), static_cast<int>(nsp), static_cast<int>(chIn_));
            mm.SetTensorA(wcGm[t * chIn_ * coutPad_ + co0], true);
            mm.SetTensorB(xGm[n * chIn_ * hinWin_ + ihlo * win_], false);
            mm.IterateAll(pGm[tBase + t * coPad_ * nsp], 0);
        }
        for (int64_t c = 0; c < coCur; ++c) {
            float bias = hasBias_ ? bGm.GetValue(co0 + c) : 0.0f;
            for (int64_t oh = oh0; oh < oh1; ++oh) {
                DoRow(n, co0 + c, c, oh, ihlo, nsp, bias, tBase);
            }
        }
    }
    mm.End();
}

}  // namespace NsConvTranspose2D

#endif // CONVTRANSPOSE2D_H
