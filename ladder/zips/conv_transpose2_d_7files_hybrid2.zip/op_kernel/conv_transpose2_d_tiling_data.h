/*!
 * \file conv_transpose2_d_tiling_data.h
 * \brief tiling data struct for ConvTranspose2D
 */

#ifndef _CONVTRANSPOSE2D_TILING_DATA_H_
#define _CONVTRANSPOSE2D_TILING_DATA_H_

#include "kernel_tiling/kernel_tiling.h"

struct ConvTranspose2DTilingData {
    int64_t totalNum = 0;     // total output element count N*Cout*Hout*Wout
    int64_t blockFactor = 1;  // output elements handled per core
    int64_t ubFactor = 0;     // staging chunk size (multiple of 64)
    // shape
    int64_t n = 1;
    int64_t chIn = 1;
    int64_t chOut = 1;
    int64_t hin = 1;
    int64_t win = 1;
    int64_t hout = 1;
    int64_t wout = 1;
    int64_t kh = 1;
    int64_t kw = 1;
    // attributes
    int64_t stride = 1;
    int64_t pad = 0;
    int64_t outPad = 0;
    int64_t dil = 1;
    int32_t hasBias = 0;
    int32_t usedCores = 1;
    int32_t useScalar = 0;
    int32_t accMode = 0;  // 2: per tap accumulators (reference order), 1: kahan folding, 0: plain
    int64_t owBlockSize = 0;  // output-width block size used by the vector path
    int64_t wbSize = 0;       // inner vector chunk width (multiple of 64)
    int32_t winSeg = 0;       // 1 = load only the needed x slice per block
    int32_t winPad = 0;       // (reserved)
    int64_t winSegSize = 0;   // padded max x-slice length when winSeg == 1

    // ---------------- cube (Matmul high level API) path ----------------
    TCubeTiling mm;           // matmul tiling for one core's tile: M=coPer, N=nspanMax, K=chIn
    int32_t useCube = 0;      // 1 = take the cube path
    int32_t isF16 = 0;        // io dtype is 16-bit
    int64_t hinWin = 0;       // hin*win (positions of one (n) image)
    int64_t ntaps = 0;        // kh*kw
    int64_t lenSec = 64;      // per-ow-phase accumulator length (multiple of 64)
    int64_t coPer = 16;       // output channels per unit (GEMM M)
    int64_t coPerPad = 16;    // P plane row count (coPer rounded up to baseM)
    int64_t ohPer = 1;        // output rows per unit
    int64_t coBlocks = 1;
    int64_t ohBlocks = 1;
    int64_t units = 0;        // n*coBlocks*ohBlocks
    int64_t perCoreElems = 0; // float elements of P workspace per core
    int64_t nspanMax = 0;     // max positions handled by one unit (row count * win)
    int32_t nfix = 8;         // max near-zero fixups per row
    float fixRatio = 5e-4f;   // near-zero cutoff = fixRatio * row absmax
    int32_t jwlo[8] = {0};    // per pw: first J_w lane
    int32_t lenPw[8] = {0};   // per pw: number of J_w lanes
    int32_t coreNum = 1;      // blockDim used by the cube path
    int64_t wcElems = 0;      // per-core float elements of the materialised weights
    int32_t coutPad = 0;      // stored A row length (chOut rounded up)
};
#endif
