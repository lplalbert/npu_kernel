/*!
 * \file conv_transpose2_d.cpp
 * Hybrid dispatch: tilingKey selects the TASK TYPE.
 *   key 0 = AIV_ONLY  -> pure vector path (no AIC, no matmul, no cross-core sync)
 *   key 1 = MIX_AIC_1_2 -> Cube path (Matmul high-level API)
 * dtype (fp16/fp32) is selected at runtime from tilingData.isF16 so only two
 * template instantiations (one per task type) are needed.
 */
#include "conv_transpose2_d.h"

enum class ConvTranspose2DTilingKey : uint32_t
{
    TILING_KEY_CONVTRANSPOSE2D_VECTOR = 0,  // AIV_ONLY
    TILING_KEY_CONVTRANSPOSE2D_CUBE = 1,    // MIX_AIC_1_2
};

template <typename T>
__aicore__ inline void RunVectorPath(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, const ConvTranspose2DTilingData& td)
{
    NsConvTranspose2D::ConvTranspose2D<T> op;
    op.Init(x, w, b, y, &td);
    op.Process();
}

template <typename T>
__aicore__ inline void RunCubePath(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, GM_ADDR userWS,
                                   const ConvTranspose2DTilingData& td)
{
    NsConvTranspose2D::ConvT2DCube<T> op;
    REGIST_MATMUL_OBJ(&op.pipe, GetSysWorkSpacePtr(), op.mm, &td.mm);
    op.Init(x, w, b, y, userWS, &td);
    op.Process();
}

template <uint32_t schMode>
__global__ __aicore__ void conv_transpose2_d(GM_ADDR x, GM_ADDR w, GM_ADDR b, GM_ADDR y, GM_ADDR workspace,
                                             GM_ADDR tiling)
{
    /* Default for any tiling key not explicitly covered below. */
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
    REGISTER_TILING_DEFAULT(ConvTranspose2DTilingData);
    GET_TILING_DATA_WITH_STRUCT(ConvTranspose2DTilingData, tilingData, tiling);

    if constexpr (schMode == static_cast<uint32_t>(ConvTranspose2DTilingKey::TILING_KEY_CONVTRANSPOSE2D_VECTOR)) {
        /* AIV-only vector path: NO matmul / no AIC handshake anywhere in this symbol. */
        if (tilingData.isF16 != 0) {
            RunVectorPath<half>(x, w, b, y, tilingData);
        } else {
            RunVectorPath<float>(x, w, b, y, tilingData);
        }
    }
    if constexpr (schMode == static_cast<uint32_t>(ConvTranspose2DTilingKey::TILING_KEY_CONVTRANSPOSE2D_CUBE)) {
        /* Establish the system (KFC) workspace base before deriving the user pointer. */
        AscendC::SetSysWorkspace(workspace);
        GM_ADDR userWS = AscendC::GetUserWorkspace(workspace);
        if (tilingData.isF16 != 0) {
            RunCubePath<half>(x, w, b, y, userWS, tilingData);
        } else {
            RunCubePath<float>(x, w, b, y, userWS, tilingData);
        }
    }

    /* Per-key task types, LITERAL keys (must match the host tilingKey values). */
    KERNEL_TASK_TYPE(0, KERNEL_TYPE_AIV_ONLY);
    KERNEL_TASK_TYPE(1, KERNEL_TYPE_MIX_AIC_1_2);
}
