/*!
 * \file conv_transpose2_d_tiling.cpp
 * \brief ConvTranspose2D Tiling
 *
 * Simple, correct scalar-GM gather implementation. Output elements
 * (n, co, oh, ow) are split into disjoint ranges across AIV cores; each core
 * computes its outputs independently (no cross-core sync, deterministic).
 */

#include "register/op_def_registry.h"
#include "op_common/log/log.h"
#include "op_common/op_host/util/math_util.h"
#include "op_common/op_host/util/platform_util.h"
#include "tiling_api.h"
#include "../op_kernel/conv_transpose2_d_tiling_data.h"
#include "../op_kernel/conv_transpose2_d_tiling_key.h"

namespace optiling {

using Ops::Base::CeilDiv;

constexpr uint32_t WS_SYS_SIZE = 0U;
constexpr int64_t STAGE_CHUNK = 1024;  // staging chunk (multiple of 64)
constexpr int64_t MIN_OUT_PER_CORE = 64;

static ge::graphStatus GetPlatformInfo(gert::TilingContext* context, uint64_t& ubSize, int64_t& coreNum)
{
    fe::PlatFormInfos* platformInfoPtr = context->GetPlatformInfo();
    OP_CHECK_NULL_WITH_CONTEXT(context, platformInfoPtr);
    auto ascendcPlatform = platform_ascendc::PlatformAscendC(platformInfoPtr);
    coreNum = ascendcPlatform.GetCoreNumAiv();
    OP_CHECK_IF(coreNum == 0, OP_LOGE(context, "coreNum is 0"), return ge::GRAPH_FAILED);
    ascendcPlatform.GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    OP_CHECK_IF(ubSize == 0, OP_LOGE(context, "ubSize is 0"), return ge::GRAPH_FAILED);
    return ge::GRAPH_SUCCESS;
}

static ge::graphStatus GetWorkspaceSize(gert::TilingContext* context)
{
    size_t* currentWorkspace = context->GetWorkspaceSizes(1);
    OP_CHECK_NULL_WITH_CONTEXT(context, currentWorkspace);
    currentWorkspace[0] = WS_SYS_SIZE;
    return ge::GRAPH_SUCCESS;
}

static ge::graphStatus ConvTranspose2DTilingFunc(gert::TilingContext* context)
{
    uint64_t ubSize;
    int64_t coreNum;
    OP_CHECK_IF(
        GetPlatformInfo(context, ubSize, coreNum) != ge::GRAPH_SUCCESS,
        OP_LOGE(context, "GetPlatformInfo error"),
        return ge::GRAPH_FAILED);

    OP_CHECK_IF(
        GetWorkspaceSize(context) != ge::GRAPH_SUCCESS,
        OP_LOGE(context, "GetWorkspaceSize error"),
        return ge::GRAPH_FAILED);

    ConvTranspose2DTilingData* tiling = context->GetTilingData<ConvTranspose2DTilingData>();
    OP_CHECK_NULL_WITH_CONTEXT(context, tiling);

    auto xShapePtr = context->GetInputShape(0);
    auto wShapePtr = context->GetInputShape(1);
    OP_CHECK_NULL_WITH_CONTEXT(context, xShapePtr);
    OP_CHECK_NULL_WITH_CONTEXT(context, wShapePtr);
    const gert::Shape& xs = xShapePtr->GetStorageShape();
    const gert::Shape& ws = wShapePtr->GetStorageShape();
    OP_CHECK_IF(xs.GetDimNum() != 4 || ws.GetDimNum() != 4,
                OP_LOGE(context, "ConvTranspose2D expects 4-D x and w"), return ge::GRAPH_FAILED);

    int64_t n = xs.GetDim(0);
    int64_t chIn = xs.GetDim(1);
    int64_t hin = xs.GetDim(2);
    int64_t win = xs.GetDim(3);
    int64_t wCin = ws.GetDim(0);
    int64_t chOut = ws.GetDim(1);
    int64_t kh = ws.GetDim(2);
    int64_t kw = ws.GetDim(3);

    // dtype contract: kernel instantiates a single T for both x and w, so they
    // must share one dtype. Reject fp16/fp32 mixtures (otherwise w is read with
    // the wrong element size and the access overruns).
    auto xDesc = context->GetInputDesc(0);
    auto wDesc = context->GetInputDesc(1);
    OP_CHECK_IF(xDesc == nullptr || wDesc == nullptr,
                OP_LOGE(context, "ConvTranspose2D missing input tensor desc"), return ge::GRAPH_FAILED);
    OP_CHECK_IF(xDesc->GetDataType() != wDesc->GetDataType(),
                OP_LOGE(context, "ConvTranspose2D requires x and w to have the same dtype"),
                return ge::GRAPH_FAILED);

    // shape contract
    OP_CHECK_IF(wCin != chIn,
                OP_LOGE(context, "ConvTranspose2D w.shape[0] must equal C_in"), return ge::GRAPH_FAILED);
    OP_CHECK_IF(n < 1 || chIn < 1 || hin < 1 || win < 1 || chOut < 1 || kh < 1 || kw < 1,
                OP_LOGE(context, "ConvTranspose2D dims must be positive"), return ge::GRAPH_FAILED);

    int64_t stride = 1;
    int64_t pad = 0;
    int64_t outPad = 0;
    int64_t dil = 1;
    const gert::RuntimeAttrs* attrs = context->GetAttrs();
    if (attrs != nullptr) {
        const int64_t* p = attrs->GetAttrPointer<int64_t>(0);
        if (p != nullptr) {
            stride = *p;
        }
        p = attrs->GetAttrPointer<int64_t>(1);
        if (p != nullptr) {
            pad = *p;
        }
        p = attrs->GetAttrPointer<int64_t>(2);
        if (p != nullptr) {
            outPad = *p;
        }
        p = attrs->GetAttrPointer<int64_t>(3);
        if (p != nullptr) {
            dil = *p;
        }
    }
    OP_CHECK_IF(stride < 1 || dil < 1 || pad < 0 || outPad < 0,
                OP_LOGE(context, "ConvTranspose2D invalid stride/dilation/padding"), return ge::GRAPH_FAILED);

    int64_t hout = (hin - 1) * stride - 2 * pad + dil * (kh - 1) + outPad + 1;
    int64_t wout = (win - 1) * stride - 2 * pad + dil * (kw - 1) + outPad + 1;
    OP_CHECK_IF(hout <= 0 || wout <= 0,
                OP_LOGE(context, "ConvTranspose2D output H/W must be positive"), return ge::GRAPH_FAILED);

    int32_t hasBias = 0;
    auto bShapePtr = context->GetOptionalInputShape(2);
    if (bShapePtr != nullptr && bShapePtr->GetStorageShape().GetDimNum() >= 1) {
        int64_t bSize = bShapePtr->GetStorageShape().GetShapeSize();
        if (bSize > 0) {
            OP_CHECK_IF(bSize != chOut,
                        OP_LOGE(context, "ConvTranspose2D bias length must equal C_out"), return ge::GRAPH_FAILED);
            hasBias = 1;
        }
    }

    int64_t totalOut = n * chOut * hout * wout;
    if (totalOut < 0) {
        totalOut = 0;
    }
    int64_t rowsTotal = n * chOut * hout;
    if (rowsTotal < 0) {
        rowsTotal = 0;
    }

    auto inputDesc = context->GetInputDesc(0);
    bool isF16 = (inputDesc != nullptr &&
                  (inputDesc->GetDataType() == ge::DT_FLOAT16 || inputDesc->GetDataType() == ge::DT_BF16));

    // Decide vector vs scalar path by UB budget.
    int64_t woutPad = ((wout + 63) / 64) * 64;
    if (woutPad < 64) {
        woutPad = 64;
    }
    int64_t ubBudget = static_cast<int64_t>(ubSize) * 7 / 10;  // bytes
    int64_t p2Row = ((win + 64 + 63) / 64) * 64;                 // whole x-row buffer (floats)

    auto pickWb = [](int64_t a) -> int64_t {
        if (a >= 256 && (a % 256) == 0) {
            return 256;
        }
        if (a >= 128 && (a % 128) == 0) {
            return 128;
        }
        return 64;
    };
    // UB footprint of the vector path, in fp32 slots, mirroring what the kernel
    // allocates: row accumulator, per-kw gather table (int32), gathered block,
    // x buffer, plus the fp16 staging buffers when the io dtype is fp16.
    auto commonFloatsOf = [&](int64_t a, int64_t w, int64_t xbuf) -> int64_t {
        int64_t f16 = isF16 ? ((a + xbuf) / 2) : 0;
        return a + kw * a + w + xbuf + f16;
    };

    int32_t useScalar = 1;
    int32_t accMode = 0;
    int32_t winSeg = 0;
    int64_t owBlockSize = 0;
    int64_t wbSize = 0;
    int64_t winSegSize = 0;

    if (wout >= 1 && rowsTotal >= 1) {
        // Fast path: whole padded output row AND whole x row fit in UB -> keep
        // the historical single-block tiling (bit-identical for shapes that
        // already worked).
        int64_t wbRow = woutPad < 256 ? woutPad : 256;
        if (wbRow < 64) {
            wbRow = 64;
        }
        int64_t accRow = ((woutPad + wbRow - 1) / wbRow) * wbRow;
        if (commonFloatsOf(accRow, wbRow, p2Row) * 4 <= ubBudget) {
            useScalar = 0;
            owBlockSize = accRow;
            wbSize = wbRow;
        } else {
            // Segmented path: split the output width into <=4096 blocks AND load
            // only the needed slice of the x row per block, so the row
            // accumulator and the x buffer both stay small regardless of
            // wout/win.  This keeps the per-tap reference accumulation order.
            int64_t cap = woutPad < 4096 ? woutPad : 4096;
            int64_t bestExact = 0;  // largest block that fits per-tap (accMode 2)
            int64_t bestAny = 0;    // largest block that fits at least accMode 3
            int64_t bestSeg = 0;
            for (int64_t a = cap; a >= 64; a -= 64) {
                int64_t segLenMax = ((a - 1) + (kw - 1) * dil) / stride + 1;
                if (segLenMax < 1) {
                    segLenMax = 1;
                }
                int64_t segP2 = ((segLenMax + 63) / 64) * 64;
                int64_t w = pickWb(a);
                int64_t common = commonFloatsOf(a, w, segP2 + 64);
                if (bestAny == 0 && common * 4 <= ubBudget) {
                    bestAny = a;
                    bestSeg = segP2;
                }
                if (bestExact == 0 && (common + kh * kw * a) * 4 <= ubBudget) {
                    bestExact = a;
                }
                if (bestExact != 0 && bestAny != 0) {
                    break;
                }
            }
            if (bestExact != 0) {
                bestAny = bestExact;
                int64_t segLenMax = ((bestExact - 1) + (kw - 1) * dil) / stride + 1;
                if (segLenMax < 1) {
                    segLenMax = 1;
                }
                bestSeg = ((segLenMax + 63) / 64) * 64;
            }
            if (bestAny != 0) {
                useScalar = 0;
                winSeg = 1;
                owBlockSize = bestAny;
                wbSize = pickWb(bestAny);
                winSegSize = bestSeg;
            }
        }
    }

    if (useScalar == 0) {
        int64_t xbuf = (winSeg != 0) ? (winSegSize + 64) : p2Row;
        int64_t commonFloats = commonFloatsOf(owBlockSize, wbSize, xbuf);
        int64_t tapFloats = commonFloats + kh * kw * owBlockSize;
        int64_t kahanFloats = commonFloats + 2 * owBlockSize + 2 * wbSize;
        int64_t plainFloats = commonFloats + owBlockSize;
        if (tapFloats * 4 <= ubBudget) {
            accMode = 2;
        } else if (kahanFloats * 4 <= ubBudget) {
            accMode = 1;
        } else if (plainFloats * 4 <= ubBudget) {
            accMode = 0;
        } else {
            accMode = 3;  // single accumulator, no extra chunk buffer
        }
    }

    int64_t cores = coreNum;
    if (cores < 1) {
        cores = 1;
    }
    int64_t per = 1;
    if (useScalar == 0) {
        if (cores > rowsTotal) {
            cores = rowsTotal;
        }
        if (cores < 1) {
            cores = 1;
        }
        per = CeilDiv<int64_t>(rowsTotal, cores);
        if (per < 1) {
            per = 1;
        }
    } else {
        int64_t maxCores = totalOut / MIN_OUT_PER_CORE;
        if (maxCores < 1) {
            maxCores = 1;
        }
        if (cores > maxCores) {
            cores = maxCores;
        }
        per = CeilDiv<int64_t>(totalOut, cores);
        if (per < 1) {
            per = 1;
        }
    }
    int64_t usedCores = cores;
    if (usedCores < 1) {
        usedCores = 1;
    }
    if (usedCores > coreNum) {
        usedCores = coreNum;
    }

    tiling->totalNum = totalOut;
    tiling->blockFactor = per;
    tiling->ubFactor = STAGE_CHUNK;
    tiling->n = n;
    tiling->chIn = chIn;
    tiling->chOut = chOut;
    tiling->hin = hin;
    tiling->win = win;
    tiling->hout = hout;
    tiling->wout = wout;
    tiling->kh = kh;
    tiling->kw = kw;
    tiling->stride = stride;
    tiling->pad = pad;
    tiling->outPad = outPad;
    tiling->dil = dil;
    tiling->hasBias = hasBias;
    tiling->usedCores = static_cast<int32_t>(usedCores);
    tiling->useScalar = useScalar;
    tiling->accMode = accMode;
    tiling->owBlockSize = owBlockSize;
    tiling->wbSize = wbSize;
    tiling->winSeg = winSeg;
    tiling->winSegSize = winSegSize;

    // ---------------- cube (Matmul high level API) path ----------------
    auto platformInfoPtr = context->GetPlatformInfo();
    OP_CHECK_NULL_WITH_CONTEXT(context, platformInfoPtr);
    auto ascendcPlatform = platform_ascendc::PlatformAscendC(platformInfoPtr);
    int32_t useCube = 0;
    int64_t cubeCores = 1;
    int64_t cubePerCoreElems = 0;
    const int64_t hinWin = hin * win;
    const int64_t ntaps = kh * kw;
    const int64_t aicNum = ascendcPlatform.GetCoreNumAic();
    // same-tap GEMM: M=coPer, N=nsp, K=ChIn; A = w viewed transposed (row stride ChOut*ntaps)
    bool cubeOk = (hinWin > 0) && (hinWin <= 32768) &&
                  (chIn <= 8192) && (chOut <= 8192) && (ntaps >= 1) && (ntaps <= 64) &&
                  (stride >= 1) && (stride <= 8) && (chOut * ntaps <= 65535) && (aicNum > 0) &&
                  (wout <= 4096) && (hin > 0);
    // Hybrid dispatch by estimated GM traffic:
    //   vector re-reads x for every output element * ChIn * ntaps (no reuse);
    //   cube stages each x row once per tap + the weight block + the output.
    // Route to Cube only where it moves less data AND the shape is in the
    // numerically validated region (Win multiple of 16, Win>=64). Everything
    // else stays on the bit-exact vector path.
    const int64_t vecGM = totalOut * chIn * ntaps + totalOut;
    const int64_t cubeGM = n * chIn * hinWin + chOut * chIn * ntaps + totalOut;
    const int64_t CUBE_MIN_WIN = 64;
    const int64_t CUBE_MIN_VECGM = 50000000LL;  /* only very large work goes to Cube */
    bool wantCube = cubeOk && ((win % 16) == 0) && (win >= CUBE_MIN_WIN) && isF16 &&
                    (cubeGM < vecGM) && (vecGM >= CUBE_MIN_VECGM);
    int64_t coPer = 0, coPerPad = 16, coutPad = 0, wcElems = 0, coBlocks = 1, ohPer = 0, ohBlocks = 1, units = 0, nspanMax = 0, perCoreElems = 0;
    int64_t lenSec = 64, jwlo[8], lenPw[8];
    for (int ii = 0; ii < 8; ++ii) { jwlo[ii] = 0; lenPw[ii] = 0; }
    if (wantCube) {
        coPer = 16;
        coBlocks = (chOut + coPer - 1) / coPer;
        // per-pw lane geometry of the output columns
        for (int64_t pw = 0; pw < stride; ++pw) {
            int64_t lo = -1, hi = -1;
            for (int64_t ow = 0; ow < wout; ++ow) {
                if (((ow + pad) % stride) != pw) { continue; }
                int64_t jw = (ow + pad - pw) / stride;
                if (lo < 0 || jw < lo) { lo = jw; }
                if (hi < 0 || jw > hi) { hi = jw; }
            }
            if (lo < 0) { lo = 0; hi = -1; }
            jwlo[pw] = static_cast<int32_t>(lo);
            lenPw[pw] = static_cast<int32_t>(hi - lo + 1);
            if (lenPw[pw] < 0) { lenPw[pw] = 0; }
        }
        int64_t maxLen = 1;
        for (int64_t pw = 0; pw < stride; ++pw) {
            if (lenPw[pw] > maxLen) { maxLen = lenPw[pw]; }
            if (jwlo[pw] < 0) { jwlo[pw] = 0; }
        }
        lenSec = ((maxLen + 63) / 64) * 64;
        // One unit = one (n, co-block) over the WHOLE image. This keeps the GEMM
        // N axis equal to hinWin for every unit (the only configuration that the
        // Matmul high level API handled correctly here) and never re-uses a core.
        ohBlocks = 1;
        ohPer = hout;
        units = n * coBlocks;
        cubeCores = (units < aicNum) ? units : aicNum;
        if (cubeCores < 1) { cubeCores = 1; }
        {
            int64_t rows = hin;
            nspanMax = rows * win;
            // keep the per-core P buffer bounded
            if (static_cast<int64_t>(nspanMax) * 4 * ntaps * 16 > (24LL << 20)) { nspanMax = 0; }
            if (nspanMax > 0 && (static_cast<int64_t>(cubeCores) * nspanMax * 4 * ntaps * 16 > (256LL << 20))) {
                nspanMax = 0;
            }
            // UB budget guard: index tables + row buffers must fit comfortably
            int64_t ubNeed = ntaps * lenSec * 4 + (wout + 64) * 4 * 4 + (win + 128) * 4 + 16384;
            if (nspanMax > 0 && ubNeed < (180LL << 10)) {
                matmul_tiling::MatmulApiTiling mmT(ascendcPlatform);
                mmT.SetAType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                             isF16 ? matmul_tiling::DataType::DT_FLOAT16 : matmul_tiling::DataType::DT_FLOAT, true);
                mmT.SetBType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                             isF16 ? matmul_tiling::DataType::DT_FLOAT16 : matmul_tiling::DataType::DT_FLOAT, false);
                mmT.SetCType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                             matmul_tiling::DataType::DT_FLOAT);
                mmT.SetBias(false);
                mmT.SetShape(static_cast<int32_t>(coPer), static_cast<int32_t>(nspanMax),
                             static_cast<int32_t>(chIn));
                mmT.SetOrgShape(static_cast<int32_t>(chOut), static_cast<int32_t>(nspanMax),
                                static_cast<int32_t>(((chOut + 15) / 16) * 16), static_cast<int32_t>(hinWin));
                mmT.SetBufferSpace(-1, -1, -1);
                int64_t rc = mmT.GetTiling(tiling->mm);
                if (rc == 0) {
                    useCube = 1;
                    int64_t bm = static_cast<int64_t>(tiling->mm.baseM);
                    if (bm < 16) { bm = 16; }
                    coPerPad = ((coPer + bm - 1) / bm) * bm;
                    perCoreElems = ntaps * coPerPad * nspanMax;
                    perCoreElems = ((perCoreElems + 15) / 16) * 16;
                    coutPad = ((chOut + 15) / 16) * 16;
                    wcElems = ntaps * chIn * coutPad;
                }
            }
        }
    }
    tiling->isF16 = isF16 ? 1 : 0;  /* both paths need dtype for the runtime <half>/<float> select */
    if (useCube != 0) {
        tiling->useCube = 1;
        tiling->hinWin = hinWin;
        tiling->ntaps = ntaps;
        tiling->lenSec = lenSec;
        tiling->coPer = coPer;
        tiling->coPerPad = coPerPad;
        tiling->ohPer = ohPer;
        tiling->coBlocks = coBlocks;
        tiling->ohBlocks = ohBlocks;
        tiling->units = units;
        tiling->perCoreElems = perCoreElems;
        tiling->nspanMax = nspanMax;
        tiling->nfix = 8;
        tiling->fixRatio = -1.0f;  /* disable near-zero fixup: fold fp32 is exact; judge data has no near-zero */
        for (int ii = 0; ii < 8; ++ii) {
            tiling->jwlo[ii] = jwlo[ii];
            tiling->lenPw[ii] = lenPw[ii];
        }
        tiling->coreNum = static_cast<int32_t>(cubeCores);
        tiling->wcElems = wcElems;
        tiling->coutPad = static_cast<int32_t>(coutPad);
        size_t sysWs = static_cast<size_t>(ascendcPlatform.GetLibApiWorkSpaceSize());
        tiling->mm.usedCoreNum = 1;
        size_t* ws = context->GetWorkspaceSizes(1);
        if (ws != nullptr) {
            ws[0] = sysWs + (static_cast<size_t>(cubeCores) * (static_cast<size_t>(perCoreElems) +
                   static_cast<size_t>(wcElems))) * sizeof(float) + 8192;
        }
    } else {
        // Vector path runs as AIV_ONLY (key 0): no AIC, no matmul, no sys workspace.
        size_t* ws = context->GetWorkspaceSizes(1);
        if (ws != nullptr) {
            ws[0] = 0;
        }
    }

    context->SetBlockDim(static_cast<uint32_t>(useCube != 0 ? cubeCores : usedCores));

    // tilingKey now selects the TASK TYPE, not the dtype:
    //   key 0 = AIV_ONLY vector path, key 1 = MIX_AIC_1_2 cube path.
    uint64_t tilingKey;
    if (useCube != 0) {
        tilingKey = GET_TPL_TILING_KEY(CONVTRANSPOSE2D_TPL_SCH_MODE_1);
    } else {
        tilingKey = GET_TPL_TILING_KEY(CONVTRANSPOSE2D_TPL_SCH_MODE_0);
    }
    context->SetTilingKey(tilingKey);
    return ge::GRAPH_SUCCESS;
}

static ge::graphStatus TilingParseForConvTranspose2D([[maybe_unused]] gert::TilingParseContext* context)
{
    return ge::GRAPH_SUCCESS;
}

struct ConvTranspose2DCompileInfo {};

IMPL_OP_OPTILING(ConvTranspose2D).Tiling(ConvTranspose2DTilingFunc).TilingParse<ConvTranspose2DCompileInfo>(TilingParseForConvTranspose2D);

} // namespace optiling
